level_0 = {
    'terrain': 'levels/L0/level_0_terrarian.csv',
    'coins': 'levels/L0/level_0_coins.csv',
    'fg palms': 'levels/L0/level_0_fg_palms.csv',
    'bg palms': 'levels/L0/level_0_bg_palms.csv',
    'crates': 'levels/L0/level_0_crates.csv',
    'enemies': 'levels/L0/level_0_enemies.csv',
    'constraints': 'levels/L0/level_0_constraints.csv',
    'player': 'levels/L0/level_0_player.csv',
    'grass': 'levels/L0/level_0_grass.csv',}
