<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="enemy_tile" tilewidth="64" tileheight="64" tilecount="2" columns="2">
 <image source="2 - Level/graphics/enemy/setup_tile.png" width="128" height="64"/>
</tileset>
